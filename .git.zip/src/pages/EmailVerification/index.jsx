
import React from "react";
import NavBar from "../../components/NavBar";
import Footer from "../../components/Footer";
import EmailVerification from './EmailVerification';
const index = () => {
  return (
   <>
   <NavBar/>
   <EmailVerification/>
   <Footer/></>
  )
}

export default index
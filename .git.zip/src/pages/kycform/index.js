import React from 'react'
import NavBar from "../../components/NavBar";
import Footer from "../../components/Footer";
import KycForm from '../../components/KycForm';
const index = () => {
  return (
    <div>
      <NavBar />
      
      <KycForm/>
      <Footer />
    </div>
  );
}

export default index
